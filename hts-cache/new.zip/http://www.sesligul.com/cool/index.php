<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <title>SesliGul.Com | Sesli Chat Mobil, Sesli Sohbet Sitesi Odaları Sohbet Girişi</title>
    <meta name="keywords" content="sesli chat,sesli siteler,mobil sesli chat,sesli sohbet mobil sohbet"/>
    <meta name="description" content="SesliGul.Com , Mobil Sohbet Odaları , Mobil Chat Sohbet Sitesi imkanı sağlayan ücretsiz mobil giriş sağlayan chat sitesidir."/>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta http-equiv="Pragma" content="cache"/>
    <meta name="robots" content="all"/>
    <meta name="googlebot" content="index, follow, archive"/>
    <meta name="msnbot" content="index, follow"/>
    <meta name="author" content="KariyerPanel İnternet Teknolojileri"/>
    <meta name="creation" content="12/06/2018"/>
    <meta name="author" content="DoLmA" />
    <meta name="creation" content="13/04/2020" />
    <meta name="expires" content="2020" />
   <link rel="stylesheet" type="text/css" href="theme/login/css/Reset.css" />
    <link rel="stylesheet" type="text/css" href="theme/login/css/Style-Login.css" />
    <link rel="stylesheet" type="text/css" href="theme/login/css/Css3.css" />
    <link rel="stylesheet" type="text/css" href="theme/login/css/Animate.css" />
    <link rel="shortcut icon" href="theme/login/images/favicon.ico" type="image/x-icon">
    <link rel="icon" href="theme/login/images/favicon.ico" type="image/x-icon">
    
    
    <!-- NICE SCROLL -->
	<script src="theme/login/js/1.7.0-jquery.min.js" type="text/javascript" charset="utf-8"></script>
	<script src="theme/login/js/NiceScroll.js"></script>
	<script>var $xScroll = jQuery.noConflict(); $xScroll(document).ready(function() { $xScroll("html").niceScroll();});</script>
    
    <!-- POPUP JS -->
    <script type="text/javascript">
		function Login() {
        	//var h = parseInt(screen.availHeight-70);
        	var h = 768;
        	var w = 1024;
        	var c = parseInt((screen.availWidth / 2) - (w / 2));
            var d = parseInt((screen.availHeight / 4) - (h / 4));
            var e = window.open('login.html?y='+Math.floor((Math.random()*999999999)+1), 'mavi_kedi', "toolbar=0,resizable=0,location=0,status=0,scrollbars=0,width=" + w + ",height=" + h + ",left=" + c + ",top=0");
            e.focus();
        }
		
		function ChatGiris() {
        	//var h = parseInt(screen.availHeight-70);
        	var h = 660;
        	var w = 1024;
        	var c = parseInt((screen.availWidth / 2) - (w / 2));
            var d = parseInt((screen.availHeight / 4) - (h / 4));
            var e = window.open('chat.html?y='+Math.floor((Math.random()*999999999)+1), 'mavi_kedi', "toolbar=0,resizable=0,location=0,status=0,scrollbars=0,width=" + w + ",height=" + h + ",left=" + c + ",top=0");
            e.focus();
        }
	</script>
    
    
	<!-- MY JAVASCRIPT -->
    <script type="text/javascript" src="theme/login/js/jquery-1.7.min.js"></script>
	<script type="text/javascript" src="theme/login/js/Function.js"></script>
		<script type="text/javascript" src="js/Function.js"></script>
	<script type="text/javascript" src="theme/login/js/css_browser_selector_dev.js"></script>
      
    
    <!-- SLİDER -->
    <link href="theme/login/js/Slider/Css/Style.css" rel="stylesheet" type="text/css" media="all" />
    <script type="text/javascript" src="theme/login/js/Slider/JavaScript/Easing.js"></script>
    <script type="text/javascript" src="theme/login/js/Slider/JavaScript/Cycle.js"></script>
    <script type="text/javascript" src="theme/login/js/Slider/JavaScript/Function.js"></script>
    
    
    <!---JAVA RESİM / ZOOM--->   
	<script src="theme/login/js/AjaxResim/highslide-full.js" type="text/javascript"></script>
    <link href="theme/login/js/AjaxResim/highslide.css" rel="stylesheet" type="text/css" />
    <script type="text/javascript">
        hs.graphicsDir = 'theme/login/js/AjaxResim/graphics/';
        hs.align = 'center';
        hs.transitions = ['expand', 'crossfade'];
        hs.outlineType = 'rounded-white';
        hs.fadeInOut = true;
        hs.dimmingOpacity = 0.75;
            
        // define the restraining box
        //hs.useBox = true;
        hs.width = 640;
        hs.height = 480;
            
        // Add the controlbar
        hs.addSlideshow({
            //slideshowGroup: 'group1',
            interval: 5000,
            repeat: false,
            useControls: true,
            fixedControls: 'fit',
            overlayOptions: {
                opacity: 1,
                position: 'bottom center',
                hideOnMouseOut: true
			}
		});
    </script>
	
	
	<style type="text/css">
        .PopupKapsayici {width:100%; height:100%; position:fixed; background:rgba(0,0,0,.8); z-index:9998;}
        .Popup {
            padding:7px;
            position:absolute;
			z-index:9999;
			opacity:0;
        }
        .Popup .Resim {
            background:url('theme/login/images/login/Loading.gif') no-repeat center center;
            -webkit-border-radius: 10px;
            -moz-border-radius: 10px;
            border-radius: 10px;
			position:absolute;
			width:100%;
			border:dashed 1px #CCC;
			padding:5px;
        }
        .Kapat {position:absolute; z-index:1; right:0; margin-top:-50px;}
    </style>
    <script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
    <script type="text/javascript">
            $(document).ready(function(e) {
				$('.Popup').stop().animate({top:100, left:"10%", right:"10%", opacity:1},1000,'easeOutElastic');
				$('.Kapat, body').click(function(e) {
					$('.Popup').hide("drop", { direction: "up" }, 600);
					$('.PopupKapsayici').css('display','none');
				});
            });
			window.onresize = function(event) {
				$('.Popup').stop().animate({top:100, left:"20%", right:"20%", opacity:1},1000,'easeOutElastic');
            };
    </script>
    <style>
        .selecticon {
            position: absolute;
            left: 24%;
            right: 33%;
            border-radius: 25%;
            top: 171px;
            background: #325c8e;
            display: none;
            width: 512px;
            z-index: 999;
            height: 485px;
            border: 16px solid #1a67b9;
            padding: 7px;
            overflow: auto;
        }

        .selecticon ul.liste li:hover {
            margin-bottom: 2px;
            background-color: #DDDFFF;
            border: solid 1px #336699;
            border-bottom: solid 4px #336699;
        }

        .selecticon ul.liste li {
            float: left;
            height: 61px;
            background-color: #a8aeec;
            border: solid 1px #9e9e9d;
            margin: 2px;
            padding: 2px;
            margin-bottom: 5px;
            cursor: pointer;
        }

        .selecticon ul.liste li img {
width: 41px;
    height: 53px;
    border-bottom-left-radius: 8px;
    background-color: #FFF;
    border: solid 1px #AAA;
    margin: 2px;
    padding: 2px;
        }

        .selecticon .header {
            height: 29px;
            padding: 7px;
            width: 100%;
            text-align: center;
            font-family: 'Trebuchet Ms';
            font-weight: 500;
            color: #ffffff;
            background-color: #d78f17;
            font-size: 22px;
            padding-top: 10px;
        }
    </style>
    <script>
        var prefix = "/cool/";
        var popupgenislik = "1024";
        var popupyukseklik = "750";
    </script>
  
    <script src="theme/login/js/wow.js" type="text/javascript"></script>
    <script type="text/javascript">
        wow = new WOW(
            {
            animateClass: 'animated',
            offset:100,
            callback:function(box) {
            console.log("WOW: animating <" + box.tagName.toLowerCase() + ">")
            }
        }
    );
    wow.init();
function ikonsecss() {

$("#selecticon").load(prefix+"ikonsec.php?page=loginicons");
$("#selecticon").show();

}
function registeruser() {
    window.open(prefix+"/getprofile/index.php?e=register", "register", "toolbar=1,status=center,width=980,height=620");
}
        function SayfaAc2(url, genislik, yukseklik) {
            winpops = window.open(url, "", "width=980,height=670,fullscreen=no,scrollbars=no,location=no,directories=no,status=yes,menubar=no,toolbar=no,resizable=no")
        }

    </script>
</head >
<body>


<!-- 

    Büyük bir heycanla ahanda KariyerPanel çıkardı diye kaynağa bakan taklitçilere Adrese Teslim Not : 
    
    Sizleri asla küçümsemiyoruz. Haddimiz de değil zaten.
	
    Ama siz büyük işler yapmak yerine küçük işlerle vakit kaybediyorsunuz.
    
    Çakma panellerinizi heycanla bekliyoruz:) 
	
    Extra 1-2 özellik daha ekleyince tam çin malları gibi oluyor.
    
    Biz yapalım siz takibe devam edin.
     
    KariyerPanel Web Bilişim Hizmetleri,
	
    Saygılar. aLi ( DoLmA )
	
-->
<div class="Kapsayici">
    <!-- KAPSAYICI -->
    <div class="selecticon animated flipInY" id="selecticon"></div>
    <div class="Logo animated fadeInLeft"><a href="index.php" title="SesliGul.Com | Sesli Chat Mobil, Sesli Sohbet Sitesi Odaları"><img
                    src="uploads/logo/ed31710d10431edc07bcfb66d4c92bfd.png" alt="Logo" title="Logo" width="220"
                    height="90"/></a></div>
    <div class="online_kisi animated flipInY"><span>1190 </span> KİŞİ SOHBET EDİYOR
    </div>
    <div class="icon_menu">
        <!-- ICON MENU -->
        <a href="skype:gulguzeli_55?call" target="_blank" title="" class="icon_menu_01 wow fadeInDown" data-wow-duration="1s" data-wow-delay="0.1s">ONLINE<span>DESTEK</span></a>
        <a href="skype:gulguzeli_55?call" target="_blank" title="" class="icon_menu_02 wow fadeInDown" data-wow-duration="1s" data-wow-delay="0.2s">SKYPE<span>DESTEK</span></a>
        </div><!--// ICON MENU -->
	    <div class="icon1_menu">
        <!-- ICON MENU -->
        <a href="#" title="" target="_blank"  title="" class="icon_menu_03 wow fadeInDown" data-wow-duration="1s" data-wow-delay="0.3s">VİDEO<span>DESTEK</span></a>
        <a href="http://activex.speakychat.com/spinstaller11.exe" target="_blank" title="" class="icon_menu_04 wow fadeInDown" data-wow-duration="1s" data-wow-delay="0.4s">ACTIVEX<span>İNDİR</span></a>
	</div><!--// ICON MENU -->
	
	    <!-- SCP ONLINE ÜYELER -->
    <div class="online_uyeler animated shake">
        <h3></span></h3>
	    <div>
            
               <img onerror="this.src='/theme/kariyer/images/noimageall.png';" src="uploads/184x130/a1420f92db39eb16413506ff622cc5db.gif" alt="YORGUN" title="YORGUN" width="90" height="90" />
               <img onerror="this.src='/theme/kariyer/images/noimageall.png';" src="uploads/184x130/c877718415b2d4c6025a285b96f73161.jpg" alt="AdiBendeSakLi" title="AdiBendeSakLi" width="90" height="90" />
               <img onerror="this.src='/theme/kariyer/images/noimageall.png';" src="uploads/184x130/5619c80a31559e0ee0e1106d0c85145a.jpg" alt="EL!F" title="EL!F" width="90" height="90" />
               <img onerror="this.src='/theme/kariyer/images/noimageall.png';" src="uploads/184x130/93c7532037d3d0ef86043ee901914068.jpg" alt="MeRWe" title="MeRWe" width="90" height="90" />
               <img onerror="this.src='/theme/kariyer/images/noimageall.png';" src="uploads/184x130/57c0c0eb22bca69778d4e36477288124.jpg" alt="JÖH" title="JÖH" width="90" height="90" />
               <img onerror="this.src='/theme/kariyer/images/noimageall.png';" src="uploads/184x130/a39764aba8a5e7baaa7c062c295b99f4.jpg" alt="DAMARCI" title="DAMARCI" width="90" height="90" />
               <img onerror="this.src='/theme/kariyer/images/noimageall.png';" src="uploads/184x130/3a2e2a79e502c9a3ddb8dc38c30a52c1.jpg" alt="Green_" title="Green_" width="90" height="90" />
               <img onerror="this.src='/theme/kariyer/images/noimageall.png';" src="uploads/184x130/37481a3476847894dea9bf66c93a3b3b.jpg" alt="- NaRin ,`" title="- NaRin ,`" width="90" height="90" />
               <img onerror="this.src='/theme/kariyer/images/noimageall.png';" src="uploads/184x130/b5d1a31bd9ea756286cc746b7385d7f5.jpg" alt="¬ ` lL å í lL å ´!!" title="¬ ` lL å í lL å ´!!" width="90" height="90" />
               <img onerror="this.src='/theme/kariyer/images/noimageall.png';" src="uploads/184x130/e324358f1de792354ba279f3470d464e.gif" alt="SUS_GÖNLÜM" title="SUS_GÖNLÜM" width="90" height="90" />
               <img onerror="this.src='/theme/kariyer/images/noimageall.png';" src="uploads/184x130/ad83c9bea979ef2d070dd545a2af1895.jpg" alt="SAKLIMDASIN" title="SAKLIMDASIN" width="90" height="90" />
               <img onerror="this.src='/theme/kariyer/images/noimageall.png';" src="uploads/184x130/ad58aef8871f2c55c509e06006dd831d.gif" alt="queen" title="queen" width="90" height="90" />
               <img onerror="this.src='/theme/kariyer/images/noimageall.png';" src="uploads/184x130/7b330f2982115f99419c18762133e7d3.gif" alt="gezgin_07" title="gezgin_07" width="90" height="90" />
               <img onerror="this.src='/theme/kariyer/images/noimageall.png';" src="uploads/184x130/f0a15a3277495fd0e39cb8b2f632873a.jpg" alt="folex" title="folex" width="90" height="90" />
               <img onerror="this.src='/theme/kariyer/images/noimageall.png';" src="uploads/184x130/7a16a16fcba539bfc7c88a2eb95cb27f.jpg" alt="E L E N A" title="E L E N A" width="90" height="90" />
               <img onerror="this.src='/theme/kariyer/images/noimageall.png';" src="uploads/184x130/dc6f3c38617c396a2d1fd415b2ccdfe3.gif" alt="SıLaa" title="SıLaa" width="90" height="90" />
               <img onerror="this.src='/theme/kariyer/images/noimageall.png';" src="uploads/184x130/db42a3d1e7516468512b57d09fa1d394.jpeg" alt="# ,`[K] â ß u š`x.!" title="# ,`[K] â ß u š`x.!" width="90" height="90" />
               <img onerror="this.src='/theme/kariyer/images/noimageall.png';" src="uploads/184x130/731d074044e3c52c67d1f06f8cb8eff0.jpg" alt="NazlicaN_" title="NazlicaN_" width="90" height="90" />
               <img onerror="this.src='/theme/kariyer/images/noimageall.png';" src="uploads/184x130/e9d004b85d90b48d6fd83c69d6311037.jpg" alt="YaSeMeN" title="YaSeMeN" width="90" height="90" />
               <img onerror="this.src='/theme/kariyer/images/noimageall.png';" src="uploads/184x130/268f86a3943756d85be4b7038430cf3e.gif" alt="LaL..!!" title="LaL..!!" width="90" height="90" />
               <img onerror="this.src='/theme/kariyer/images/noimageall.png';" src="uploads/184x130/6e0211dab319005854889f194b8311bf.jpg" alt="DiLa" title="DiLa" width="90" height="90" />
               <img onerror="this.src='/theme/kariyer/images/noimageall.png';" src="uploads/184x130/291100aaa88aad6f407f028c1fd9150e.jpg" alt="HayaL" title="HayaL" width="90" height="90" />
               <img onerror="this.src='/theme/kariyer/images/noimageall.png';" src="uploads/184x130/3a00b652da5dc9113b2982dab518b248.jpg" alt="ALİ" title="ALİ" width="90" height="90" />
               <img onerror="this.src='/theme/kariyer/images/noimageall.png';" src="uploads/184x130/165e8f5252e577c82a054884a52b0a93.jpg" alt="Ø.Ḽ.Ủ Ặ.Đ.Ẳ.Ṃ" title="Ø.Ḽ.Ủ Ặ.Đ.Ẳ.Ṃ" width="90" height="90" />		
        </div>
    </div>
    <!-- // SCP ONLINE ÜYELER -->
   
	<div class="sohbet_login animated flipInX"><!-- SOHBET LOGİN -->
		<div class="login_buttons">
			<a href="#Misafir-Login" class="misafir_login_btn aktif">MİSAFİR</a>
			<a href="#Uye-Login" class="uye_login_btn">ÜYE</a>
			<a href="#Yetkili-Login" class="yetkili_login_btn">YETKİLİ</a>
		</div>
		<div class="login_form">
            <form action="login.php" method="post" name="logininform"><input type="text" name="kadi" class="Kadi"
                                                                                                                                                          placeholder="Kullanıcı Adınız"/> <input
                        type="password" name="sifre" class="Sifre pasif_form" readonly="readonly"
                        placeholder="Şifreiniz"/> <input type="password" name="sifre2" class="YoneticiSifre pasif_form"
                                                         readonly="readonly" placeholder="Yönetici Şifreniz"/> <input
                        value="Erkek" type="hidden" name="cinsiyet" id="cinsiyet"> <input value="" type="hidden"
                                                                                          name="icon" id="icon"> <input
                        value="" type="hidden" name="durum" id="durum"> <input type="submit" name="Giris"
                                                                               class="Giris_Btn"/></form>
        </div>
        <div class="yan_butonlar"><a href="#Bay" title="" class="Bay"></a>
            <a href="#Bayan" title="" class="Bayan"></a>

            <a href="javascript:ikonsecss();" title="" class="Avatar"></a>
        </div>
    </div>
    <!--// SOHBET LOGİN -->
	<div class="duvar_yazilari_slider"><!-- DUVAR YAZILARI SLİDER -->
			<div class="adam_kol"></div>
			<div class="duvar_yazilari_listele">
			   

 <div><!-- SCP YAZI -->
					<div>
						<div class="text-bg-mavi">
						<a href="#" title=""><div class="resim_cerceve"><img class="duvar_resim" onerror="this.src='/cool/images2/noimageall.png';" src="/always/temp/Erkek_3.jpg" alt="" title="" width="100" height="100" /></div></a>
						<p class="duvar_baslik">BARIŞ21</p>
						<p class="duvar_ozet">ALEM. BİTER TETİK DÜŞER</p>
						</div>
					</div> 
					
             
			
					<div>
						<div class="text-bg-kirmizi">
						<a href="#" title=""><div class="resim_cerceve"><img class="duvar_resim" onerror="this.src='/cool/images2/noimageall.png';" src="/always/uploads/120x120/291100aaa88aad6f407f028c1fd9150e.jpg" alt="" title="" width="100" height="100" /></div></a>
						<p class="duvar_baslik">HayaL</p>
						<p class="duvar_ozet">HavaLar NasıL OLursa OLsun" Sizin Havanız İyi OLsun..!</p>
						</div>
					</div> 
				</div><!-- // SCP YAZI -->
				
   

 <div><!-- SCP YAZI -->
					<div>
						<div class="text-bg-mavi">
						<a href="#" title=""><div class="resim_cerceve"><img class="duvar_resim" onerror="this.src='/cool/images2/noimageall.png';" src="/always/uploads/184x130/e324358f1de792354ba279f3470d464e.gif" alt="" title="" width="100" height="100" /></div></a>
						<p class="duvar_baslik">SUS_GÖNLÜM</p>
						<p class="duvar_ozet">seste dert var,,,,,, acı var,,,,,, çile var,,,,, bide huzur var,,,,, dinle dinle bıkmassın ,,,,</p>
						</div>
					</div> 
					
             
			
					<div>
						<div class="text-bg-kirmizi">
						<a href="#" title=""><div class="resim_cerceve"><img class="duvar_resim" onerror="this.src='/cool/images2/noimageall.png';" src="/always/uploads/120x120/e324358f1de792354ba279f3470d464e.gif" alt="" title="" width="100" height="100" /></div></a>
						<p class="duvar_baslik">SUS_GÖNLÜM</p>
						<p class="duvar_ozet">Sen ölürsen,,,,göğün canı çekilir,,,,,ağlaşır yıldızlar,,,,,,,,,ay küser geceye,,,,,,yağmur düşer toprağa,,,,,,yetim kalır bulutlar,,,,,,sen ölme,,,,,,,,,</p>
						</div>
					</div> 
				</div><!-- // SCP YAZI -->
				
   

 <div><!-- SCP YAZI -->
					<div>
						<div class="text-bg-mavi">
						<a href="#" title=""><div class="resim_cerceve"><img class="duvar_resim" onerror="this.src='/cool/images2/noimageall.png';" src="/always/uploads/184x130/d07fcc2665d3c6d0b4d74dec020e86d1.jpg" alt="" title="" width="100" height="100" /></div></a>
						<p class="duvar_baslik"># Y@L@N_DüNY@ #</p>
						<p class="duvar_ozet">Düşerken iki şeyi asla unutma: kimin seni ittiğini ve kimin seni tutmadığını. Ayağa tekrar kalkınca lazım olacak.</p>
						</div>
					</div> 
					
             
			
					<div>
						<div class="text-bg-kirmizi">
						<a href="#" title=""><div class="resim_cerceve"><img class="duvar_resim" onerror="this.src='/cool/images2/noimageall.png';" src="/always/uploads/120x120/ad83c9bea979ef2d070dd545a2af1895.jpg" alt="" title="" width="100" height="100" /></div></a>
						<p class="duvar_baslik">SAKLIMDASIN</p>
						<p class="duvar_ozet">Hiçbir tesadüf senin kadar muhteşem değildi ...??</p>
						</div>
					</div> 
				</div><!-- // SCP YAZI -->
				
   

 <div><!-- SCP YAZI -->
					<div>
						<div class="text-bg-mavi">
						<a href="#" title=""><div class="resim_cerceve"><img class="duvar_resim" onerror="this.src='/cool/images2/noimageall.png';" src="/always/uploads/184x130/6989840f3f11a2f4f8c6bb6ed320e2cc.jpg" alt="" title="" width="100" height="100" /></div></a>
						<p class="duvar_baslik">TRoL</p>
						<p class="duvar_ozet">Bizimkisi bir aşk hikayesi değil,sadece bir tesadüftü..</p>
						</div>
					</div> 
					
             
			
					<div>
						<div class="text-bg-kirmizi">
						<a href="#" title=""><div class="resim_cerceve"><img class="duvar_resim" onerror="this.src='/cool/images2/noimageall.png';" src="/always/uploads/120x120/3501078d63ab5dce7f43840f31fb18fd.jpg" alt="" title="" width="100" height="100" /></div></a>
						<p class="duvar_baslik">~Q-s†])ãh</p>
						<p class="duvar_ozet">Ne diyoruz bu saatten sonra ! Giden gittiği yeri mutlu etsin bizi değil.</p>
						</div>
					</div> 
				</div><!-- // SCP YAZI -->
				
   

 <div><!-- SCP YAZI -->
					<div>
						<div class="text-bg-mavi">
						<a href="#" title=""><div class="resim_cerceve"><img class="duvar_resim" onerror="this.src='/cool/images2/noimageall.png';" src="/always/uploads/184x130/c1b7732691d37e8a2a09fc8cabce38cd.jpeg" alt="" title="" width="100" height="100" /></div></a>
						<p class="duvar_baslik">SâL_Lâ !</p>
						<p class="duvar_ozet">Bizim çıkarsız yaşantımız sizin Menfeaat terazinizi bozar .</p>
						</div>
					</div> 
					
             
			
					<div>
						<div class="text-bg-kirmizi">
						<a href="#" title=""><div class="resim_cerceve"><img class="duvar_resim" onerror="this.src='/cool/images2/noimageall.png';" src="/always/uploads/120x120/165e8f5252e577c82a054884a52b0a93.jpg" alt="" title="" width="100" height="100" /></div></a>
						<p class="duvar_baslik">Ø.Ḽ.Ủ Ặ.Đ.Ẳ.Ṃ</p>
						<p class="duvar_ozet">Gönlü Kâbe Olmayanın,</p>
						</div>
					</div> 
				</div><!-- // SCP YAZI -->
				
   

 <div><!-- SCP YAZI -->
					<div>
						<div class="text-bg-mavi">
						<a href="#" title=""><div class="resim_cerceve"><img class="duvar_resim" onerror="this.src='/cool/images2/noimageall.png';" src="/always/uploads/184x130/731d074044e3c52c67d1f06f8cb8eff0.jpg" alt="" title="" width="100" height="100" /></div></a>
						<p class="duvar_baslik">NazlicaN_</p>
						<p class="duvar_ozet">"EmiR Aldigim Tek kisi,Keyfim",...!</p>
						</div>
					</div> 
					
             
			
					<div>
						<div class="text-bg-kirmizi">
						<a href="#" title=""><div class="resim_cerceve"><img class="duvar_resim" onerror="this.src='/cool/images2/noimageall.png';" src="/always/uploads/120x120/f50a3a75cfb071248b6fc062b52bfc6c.jpg" alt="" title="" width="100" height="100" /></div></a>
						<p class="duvar_baslik"># uzaqDuR.!</p>
						<p class="duvar_ozet">Kendini bulunmaz Hint kumaşı sananlara duyurulur artık Hint kumaşının devri bitti.</p>
						</div>
					</div> 
				</div><!-- // SCP YAZI -->
				
   

 <div><!-- SCP YAZI -->
					<div>
						<div class="text-bg-mavi">
						<a href="#" title=""><div class="resim_cerceve"><img class="duvar_resim" onerror="this.src='/cool/images2/noimageall.png';" src="/always/temp/Erkek_1.jpg" alt="" title="" width="100" height="100" /></div></a>
						<p class="duvar_baslik">devran_34</p>
						<p class="duvar_ozet">İNSANLIK BİR NİMETTİR HERKESE NASİP OLMAZ</p>
						</div>
					</div> 
					
             
			
					<div>
						<div class="text-bg-kirmizi">
						<a href="#" title=""><div class="resim_cerceve"><img class="duvar_resim" onerror="this.src='/cool/images2/noimageall.png';" src="/always/temp/Erkek_1.jpg" alt="" title="" width="100" height="100" /></div></a>
						<p class="duvar_baslik">devran_34</p>
						<p class="duvar_ozet">HİÇBİR YAPRAK GÖZDEN DÜŞEN BİR İNSAN KADAR HIZLI DÜŞMEMİŞTİR YERE</p>
						</div>
					</div> 
				</div><!-- // SCP YAZI -->
				
   

 <div><!-- SCP YAZI -->
					<div>
						<div class="text-bg-mavi">
						<a href="#" title=""><div class="resim_cerceve"><img class="duvar_resim" onerror="this.src='/cool/images2/noimageall.png';" src="/always/temp/Erkek_5.jpg" alt="" title="" width="100" height="100" /></div></a>
						<p class="duvar_baslik">devran_34</p>
						<p class="duvar_ozet">ESKİDEN ÇAYI DEMLİ İÇERDİK HARBİ ADAMLARLA GEZERDİK ŞİMDİ ÇAYLAR SALLAMA ADAMLAR DALLAMA OLMUŞ.</p>
						</div>
					</div> 
					
             
			
					<div>
						<div class="text-bg-kirmizi">
						<a href="#" title=""><div class="resim_cerceve"><img class="duvar_resim" onerror="this.src='/cool/images2/noimageall.png';" src="/always/uploads/120x120/3501078d63ab5dce7f43840f31fb18fd.jpg" alt="" title="" width="100" height="100" /></div></a>
						<p class="duvar_baslik">~Q-s†])ãh</p>
						<p class="duvar_ozet">Gözün Arkada Kalıcaksa Maerifet Deyildir GİTMEK !!!!!</p>
						</div>
					</div> 
				</div><!-- // SCP YAZI -->
				
   

 <div><!-- SCP YAZI -->
					<div>
						<div class="text-bg-mavi">
						<a href="#" title=""><div class="resim_cerceve"><img class="duvar_resim" onerror="this.src='/cool/images2/noimageall.png';" src="/always/uploads/184x130/6e0211dab319005854889f194b8311bf.jpg" alt="" title="" width="100" height="100" /></div></a>
						<p class="duvar_baslik">DiLa</p>
						<p class="duvar_ozet">dost dost dedik dost görünüşlü post geymiş yalancı insanlardan sen koru rabbim</p>
						</div>
					</div> 
					
             
			
					<div>
						<div class="text-bg-kirmizi">
						<a href="#" title=""><div class="resim_cerceve"><img class="duvar_resim" onerror="this.src='/cool/images2/noimageall.png';" src="/always/uploads/120x120/731d074044e3c52c67d1f06f8cb8eff0.jpg" alt="" title="" width="100" height="100" /></div></a>
						<p class="duvar_baslik">NazlicaN_</p>
						<p class="duvar_ozet">Yüzünü"YALANLA" yikayan,"IHANET" ile KurulaniR,.!</p>
						</div>
					</div> 
				</div><!-- // SCP YAZI -->
				
   

 <div><!-- SCP YAZI -->
					<div>
						<div class="text-bg-mavi">
						<a href="#" title=""><div class="resim_cerceve"><img class="duvar_resim" onerror="this.src='/cool/images2/noimageall.png';" src="/always/uploads/184x130/40b5797770dc5d3ac78f28d6cc3f56f5.gif" alt="" title="" width="100" height="100" /></div></a>
						<p class="duvar_baslik">GöKmEn</p>
						<p class="duvar_ozet">Basit  insanlarla buyuk  hesabim olmaz herkes  ederi  kadar..!!</p>
						</div>
					</div> 
					
             
			
					<div>
						<div class="text-bg-kirmizi">
						<a href="#" title=""><div class="resim_cerceve"><img class="duvar_resim" onerror="this.src='/cool/images2/noimageall.png';" src="/always/temp/Erkek_1.jpg" alt="" title="" width="100" height="100" /></div></a>
						<p class="duvar_baslik">BaRo</p>
						<p class="duvar_ozet">hakımda bilgin yoksa fikrinde olmasın</p>
						</div>
					</div> 
				</div><!-- // SCP YAZI -->
				
   

 <div><!-- SCP YAZI -->
					<div>
						<div class="text-bg-mavi">
						<a href="#" title=""><div class="resim_cerceve"><img class="duvar_resim" onerror="this.src='/cool/images2/noimageall.png';" src="/always/temp/Erkek_4.jpg" alt="" title="" width="100" height="100" /></div></a>
						<p class="duvar_baslik">gezgin-07</p>
						<p class="duvar_ozet">yeni paneliniz hayırlı olsun</p>
						</div>
					</div> 
					
             
			
					<div>
						<div class="text-bg-kirmizi">
						<a href="#" title=""><div class="resim_cerceve"><img class="duvar_resim" onerror="this.src='/cool/images2/noimageall.png';" src="/always/uploads/120x120/f4482b887e43a8344a66f0308721bf68.png" alt="" title="" width="100" height="100" /></div></a>
						<p class="duvar_baslik">YeSs..!</p>
						<p class="duvar_ozet">İyileştirir diye medet umduklarımız tekrar tekrar yaralıyor bizi.</p>
						</div>
					</div> 
				</div><!-- // SCP YAZI -->
				
   

 <div><!-- SCP YAZI -->
					<div>
						<div class="text-bg-mavi">
						<a href="#" title=""><div class="resim_cerceve"><img class="duvar_resim" onerror="this.src='/cool/images2/noimageall.png';" src="/always/uploads/184x130/f4482b887e43a8344a66f0308721bf68.png" alt="" title="" width="100" height="100" /></div></a>
						<p class="duvar_baslik">YeSs..!</p>
						<p class="duvar_ozet">Sabrımın sınırları taştığında hayatımdan silemeyeceğim insan yoktur.</p>
						</div>
					</div> 
					
             
			
					<div>
						<div class="text-bg-kirmizi">
						<a href="#" title=""><div class="resim_cerceve"><img class="duvar_resim" onerror="this.src='/cool/images2/noimageall.png';" src="/always/uploads/120x120/7a0cef1e0115193605758ff3ae3d73fa.gif" alt="" title="" width="100" height="100" /></div></a>
						<p class="duvar_baslik">KaLpSiz</p>
						<p class="duvar_ozet">Tabağına yiyebileceğin kadar yemek hayatına sevebileceğin kadar insan al İsrafın lüzumu yok</p>
						</div>
					</div> 
				</div><!-- // SCP YAZI -->
				
   

 <div><!-- SCP YAZI -->
					<div>
						<div class="text-bg-mavi">
						<a href="#" title=""><div class="resim_cerceve"><img class="duvar_resim" onerror="this.src='/cool/images2/noimageall.png';" src="/always/temp/Erkek_5.jpg" alt="" title="" width="100" height="100" /></div></a>
						<p class="duvar_baslik">Mc YaKıŞıKLı</p>
						<p class="duvar_ozet">zincire vurulmuş duygularımla oynamayın</p>
						</div>
					</div> 
					
             
			
					<div>
						<div class="text-bg-kirmizi">
						<a href="#" title=""><div class="resim_cerceve"><img class="duvar_resim" onerror="this.src='/cool/images2/noimageall.png';" src="/always/uploads/120x120/c4a77cd573601cfad60dc7436cc7f4e9.jpg" alt="" title="" width="100" height="100" /></div></a>
						<p class="duvar_baslik">aSiL_HaNıM</p>
						<p class="duvar_ozet">lütfen gagımı acarmısınız</p>
						</div>
					</div> 
				</div><!-- // SCP YAZI -->
				
   

 <div><!-- SCP YAZI -->
					<div>
						<div class="text-bg-mavi">
						<a href="#" title=""><div class="resim_cerceve"><img class="duvar_resim" onerror="this.src='/cool/images2/noimageall.png';" src="/always/uploads/184x130/731d074044e3c52c67d1f06f8cb8eff0.jpg" alt="" title="" width="100" height="100" /></div></a>
						<p class="duvar_baslik">NazlicaN_</p>
						<p class="duvar_ozet">"Hayat 3/5Hesabi icin cok Kisa....</p>
						</div>
					</div> 
					
             
			
					<div>
						<div class="text-bg-kirmizi">
						<a href="#" title=""><div class="resim_cerceve"><img class="duvar_resim" onerror="this.src='/cool/images2/noimageall.png';" src="/always/uploads/120x120/a39764aba8a5e7baaa7c062c295b99f4.jpg" alt="" title="" width="100" height="100" /></div></a>
						<p class="duvar_baslik">DAMARCI</p>
						<p class="duvar_ozet">bozkurt kışı atlatırmış ama yediği ayazı da unutmazmış çakalların hükmü kurtlar ayağa kalkana kadardır</p>
						</div>
					</div> 
				</div><!-- // SCP YAZI -->
				
   

 <div><!-- SCP YAZI -->
					<div>
						<div class="text-bg-mavi">
						<a href="#" title=""><div class="resim_cerceve"><img class="duvar_resim" onerror="this.src='/cool/images2/noimageall.png';" src="/always/uploads/184x130/d6b95e1520102b28864818d069c78275.jpg" alt="" title="" width="100" height="100" /></div></a>
						<p class="duvar_baslik">GüL_GüZeLi.</p>
						<p class="duvar_ozet">Sitemize aktivite yükLe GiRiş yap  teLefon tabLet giRiş  aCıktıRtıR</p>
						</div>
					</div> 
					
             
			
					<div>
						<div class="text-bg-kirmizi">
						<a href="#" title=""><div class="resim_cerceve"><img class="duvar_resim" onerror="this.src='/cool/images2/noimageall.png';" src="/always/uploads/120x120/d6b95e1520102b28864818d069c78275.jpg" alt="" title="" width="100" height="100" /></div></a>
						<p class="duvar_baslik">GüL_GüZeLi.</p>
						<p class="duvar_ozet">Siteye googLe ChRomedan giRiniz diğeRi  GiRmiyoR  ORjınaL  StandaRt oLan ChRome</p>
						</div>
					</div> 
				</div><!-- // SCP YAZI -->
				
   

 <div><!-- SCP YAZI -->
					<div>
						<div class="text-bg-mavi">
						<a href="#" title=""><div class="resim_cerceve"><img class="duvar_resim" onerror="this.src='/cool/images2/noimageall.png';" src="/always/uploads/184x130/d6b95e1520102b28864818d069c78275.jpg" alt="" title="" width="100" height="100" /></div></a>
						<p class="duvar_baslik">GüL_GüZeLi.</p>
						<p class="duvar_ozet">Siteye Giriş YapamıyorSanız İnternet Explorden Giriniz  Aktivite Yükleyiniz Telefondanda GireBilirsiniz.. Sitemize ..</p>
						</div>
					</div> 
					
             
			
					<div>
						<div class="text-bg-kirmizi">
						<a href="#" title=""><div class="resim_cerceve"><img class="duvar_resim" onerror="this.src='/cool/images2/noimageall.png';" src="/always/uploads/120x120/874a216877f3c3bb882de17a35e93f51.jpg" alt="" title="" width="100" height="100" /></div></a>
						<p class="duvar_baslik">GüL_GüZeLi</p>
						<p class="duvar_ozet">Selam Herkeze Mobil Sitemiz HErkeze HayirLi OLsun Hoş Sohbetler Dilerim  .. Herşey SizLer için .. Skype : gulguzeli55</p>
						</div>
					</div> 
				</div><!-- // SCP YAZI -->
				






            </div>
            <a href="javascript:;" id="Duvar_SliderGeri"></a>
            <a href="javascript:;" id="Duvar_SliderIleri"></a>
        </div><!--// DUVAR YAZILARI SLİDER -->
</div>
<!--// KAPSAYICI -->
</body>

</html>