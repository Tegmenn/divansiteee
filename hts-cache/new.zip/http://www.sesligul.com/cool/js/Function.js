/* SAYFA YÜKLENİYOR */

function Yuklendi(){	

	

	/* SAYFA YÜKLENDİKTEN SONRA ÇAĞIRMA */

	var callbackFunc = function(){

		console.log('file loaded');     

	};

	var head = document.getElementsByTagName( "head" )[0];

	var fileref=document.createElement("link");

	fileref.setAttribute("rel", "stylesheet");

	fileref.setAttribute("type", "text/css");

	fileref.setAttribute("href", "css/Animate.css");

	

	fileref.onload  = callbackFunc;

	head.insertBefore( fileref, head.firstChild );

		

}

window.onload = Yuklendi;


function odaGetir(roomid,nereye){
	if(nereye!="")
	{
	mychat.ReconnectClient(roomid);
	}
	$('.aktif_oda_bilgisi').load('ajax.php?modul=oda_aktif_bilgisi&id='+nereye+'&nereye='+roomid);
	if(!nereye){

	}
		if(getQueryString('tam_ekran') == '1'){
		$('.roomload').hide(0);
		$('div.rightbar').show(0);
		$('div.activex').css("margin-left","0px");
		}
}



function f16yap()
{
if(confirm("Sayfanız yenilenecek, emin misiniz?")) {
			 location.reload();
		}
}
function cikisyap()
{
if(confirm("Çıkış yapacaksınız, emin misiniz?")) {
			$.get("login.php?cglk=logout&time="+Math.floor((Math.random()*999999999)+1),function(){
				window.location = 'index.php?yxw='+Math.floor((Math.random()*999999999)+1);
			});
		}
}

function target_popup(form) {
    window.open('', 'formpopup', 'width='+popupgenislik+',height='+popupyukseklik+',resizeable,scrollbars');
    form.target = 'formpopup';
}

function smsbisine(){
	var msg = $.trim($('input.smsyaz').val());
	if(msg.length < 10){
		alert("Mesajınız çok kısa");
		$('input.smsyaz').focus();
	}else{
		$.post('ajax.php?modul=sms_bisine',{sms:msg},function(ds){
			if($.trim(ds) == 'tamam'){
				alert('Mesajınız gönderildi. Lütfen onay sürecini bekleyiniz.');
				$('.mesaj_listele').show();
				$('.smsiyaz').hide();
			} else {
				alert(ds);
				$('.mesaj_listele').show();
				$('.smsiyaz').hide();
			}
		});
	}
}
function smsyaz()
{


if($('.smsbox').attr("id") > 0){
			$('.mesaj_listele').hide(0,function(){
				$('.smsiyaz').show().html('<div class="message"><p><form action="javascript:void(0)" method="post"><input name="sms" id="sms" autocomplete="off" class="smsyaz" type="text" style="font-size:12px; padding:4px; border:#777777 dashed 1px; width:152px" /><br><a style="color:#994689" href="javaScript:smsbisine()">Gönder</a> - <a  onClick="$(\'.mesaj_listele\').show();$(\'.smsiyaz\').hide()" style="color:#994689" href="javascript:;">Vazgeç</a></form></p></div><a href="#" class="sms_yenile refresh"></a> <a href="#" class="write"></a>');
				$('input.smsyaz').focus();
			});
		} else {
			alert("Üyelik girişi yapınız.");
		}
}
$(document).ready(function(e) {




	// CHAT SAYFASI SOSYAL BUTONLAR

	$('.sosyal_btn').click(function(e) {

      

    });

	

	

	// CHAT ÜYE RESİM

    $('.uyeler').hover(function(e) {

		$(this).find('.uye_resim_isik').stop().animate({ "marginLeft":"-20px" },500,'easeOutExpo');

	}, function(e) {

		$(this).find('.uye_resim_isik').stop().animate({ "marginLeft":"0px" },500,'easeOutExpo');

    });

	

	

	// LOGİN YAN BUTONLAR

    $('.yan_butonlar a').hover(function(e) {

		$(this).addClass('animated');

		$(this).addClass('headShake');

	}, function(e) {

		$(this).removeClass('animated');

		$(this).removeClass('headShake');

    });

	

	

	// LOGİN TAB BUTONLAR

    $('.login_buttons a').hover(function(e) {

		$(this).addClass('animated');

		$(this).addClass('fadeIn');

	}, function(e) {

		$(this).removeClass('animated');

		$(this).removeClass('fadeIn');

    });

	

	

	// LOGO EFEKT

    $('.Logo').hover(function(e) {

		$(this).find('a').addClass('float-shadow');

	}, function(e) {

		$(this).find('a').removeClass('float-shadow');

    });



	

	// MAKALE RESİM EFEKT

    $('.makale').hover(function(e) {

		$(this).find('img').addClass('animated');

		$(this).find('img').addClass('flipInX');

	}, function(e) {

		$(this).find('img').removeClass('animated');

		$(this).find('img').removeClass('flipInX');

    });

	

	

	// POPUP ÜYE RESİMLERİ EFEKT

    $('.uye_resimleri ul li').hover(function(e) {

		$(this).find('img').addClass('animated');

		$(this).find('img').addClass('flipInY');

	}, function(e) {

		$(this).find('img').removeClass('animated');

		$(this).find('img').removeClass('flipInY');

    });

	

	

	// ÜYE RESİMLER EFEKT

    $('.uye_resimler .uye_kapsayici').hover(function(e) {

		$(this).find('div').addClass('animated');

		$(this).find('div').addClass('flipInY');

	}, function(e) {

		$(this).find('div').removeClass('animated');

		$(this).find('div').removeClass('flipInY');

    });

	

	

	

	// SAYFA GALERİ EFEKT

    $('.galeri li').hover(function(e) {

		$(this).find('img').addClass('animated');

		$(this).find('img').addClass('flipInY');

	}, function(e) {

		$(this).find('img').removeClass('animated');

		$(this).find('img').removeClass('flipInY');

    });

	

	

	// YAN MENU EFEKT

    $('.yan_menu ul li').hover(function(e) {

		$(this).find('i').addClass('animated');

		$(this).find('i').addClass('flipInY');

		$(this).find('i').stop().animate({ "marginLeft":"15px" },500,'easeOutExpo');

	}, function(e) {

		$(this).find('i').removeClass('animated');

		$(this).find('i').removeClass('flipInY');

		$(this).find('i').stop().animate({ "marginLeft":"0" },500,'easeOutExpo');

    });

	

	

	// YAN MENU EFEKT

    $('.footer_menu li').hover(function(e) {

		$(this).find('i').addClass('animated');

		$(this).find('i').addClass('flipInY');

		$(this).find('i').stop().animate({ "marginLeft":"7px" },500,'easeOutExpo');

	}, function(e) {

		$(this).find('i').removeClass('animated');

		$(this).find('i').removeClass('flipInY');

		$(this).find('i').stop().animate({ "marginLeft":"0" },500,'easeOutExpo');

    });

	

	

	// ODALAR RESİM EFEKT

    $('.sohbet_odasi').hover(function(e) {

		$(this).find('img').addClass('animated');

		$(this).find('img').addClass('pulse');

	}, function(e) {

		$(this).find('img').removeClass('animated');

		$(this).find('img').removeClass('pulse');

    });

	

	

	// LOGİN BUTONLAR

    $('.login_buttons a').click(function(e) {

		$('.login_buttons a').removeClass('aktif');

        $(this).addClass('aktif');

    });

	

	

	// LOGİN FORMLAR AKTİFLİK

	$('.login_buttons a').click(function(e) {

		if ( $('.misafir_login_btn').hasClass( "aktif" ) ) {

			$('.Sifre').addClass('pasif_form');

			$('.YoneticiSifre').addClass('pasif_form');

			$('.Sifre').attr('readonly', true);

			$('.YoneticiSifre').attr('readonly', true);

		}

		if ( $('.uye_login_btn').hasClass( "aktif" ) ) {

			$('.Sifre').removeClass('pasif_form');

			$('.YoneticiSifre').addClass('pasif_form');

			$('.Sifre').attr('readonly', false);

		}

		if ( $('.yetkili_login_btn').hasClass( "aktif" ) ) {

			$('.Sifre').removeClass('pasif_form');

			$('.YoneticiSifre').removeClass('pasif_form');

			$('.Sifre').attr('readonly', false);

			$('.YoneticiSifre').attr('readonly', false);

		}

    });

	

	

 	// LOGİN BAY - BAYAN SEÇİMİ

	$('.Bay').click(function(){ 

		$(".Bayan").removeClass("aktif");

		$(this).addClass("aktif");

		$('input#cinsiyet').val("Erkek");

	});

    	

	$('.Bayan').click(function(){  

		$(".Bay").removeClass("aktif");

		$(this).addClass("aktif");

		$('input#cinsiyet').val("Bayan");

	});

	

	

	/* GO TOP */

	$('.scrollup').click(function(){  

		window.scrollTo(500, 0);

	});

	

	

});
function chatgetir()
{
document.getElementById("activexload").style.display = "none";
document.getElementById("MyChat").style.display = "block";
ChatSend.submit();
}
$(document).ready(function(){			
setTimeout("chatgetir()",1);
});