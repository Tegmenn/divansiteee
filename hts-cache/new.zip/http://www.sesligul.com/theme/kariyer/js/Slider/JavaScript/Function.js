$(document).ready(function() {
    
	// HOME SLİDER
	$('.SliderResimler').cycle({
		//fx:'blindX',
		//fx:'scrollHorz',
		fx:'fade',
		easing: 'easeInOutBack',
		containerResize: false,
		slideResize: false,
		fit: 1,
		timeout:1000,
		pause:true,
		pauseOnPagerHover:true,
		prev:'#SliderGeri',
		next:'#SliderIleri',
		pager:'#SliderPager'
	});
	
	
	// DUVAR YAZILARI
	$('.duvar_yazilari_listele').cycle({
		fx:'scrollUp',
		//fx:'scrollHorz',
		//fx:'fade',
		easing: 'easeInOutBack',
		containerResize: false,
		slideResize: false,
		fit: 1,
		timeout:3000,
		pause:true,
		pauseOnPagerHover:true,
		prev:'#Duvar_SliderGeri',
		next:'#Duvar_SliderIleri',
		pager:'#Duvar_SliderPager'
	});
	
	
	// CHAT ÜYELER SLİDER
	$('.chat_uyeler_listele').cycle({
		//fx:'scrollUp',
		//fx:'scrollHorz',
		fx:'fade',
		easing: 'easeInOutBack',
		containerResize: false,
		slideResize: false,
		fit: 1,
		timeout:3000,
		pause:true,
		pauseOnPagerHover:true,
		prev:'#chat_uyeler_SliderGeri',
		next:'#chat_uyeler_SliderIleri',
		pager:'#chat_uyeler_SliderPager'
	});
	
	
	// CHAT MESAJLAR SLİDER
	$('.mesaj_listele').cycle({
		fx:'scrollUp',
		//fx:'scrollHorz',
		//fx:'fade',
		easing: 'easeInOutBack',
		containerResize: false,
		slideResize: false,
		fit: 1,
		timeout:3000,
		pause:true,
		pauseOnPagerHover:true,
		prev:'#mesajlar_SliderGeri',
		next:'#mesajlar_SliderIleri',
		pager:'#mesajlar_SliderPager'
	});
	
	
	// SOHBET HAREKETLERİ
	$('.hareketler_listele').cycle({
		fx:'scrollHorz',
		//fx:'scrollHorz',
		//fx:'fade',
		easing: 'easeInOutBack',
		containerResize: false,
		slideResize: false,
		fit: 1,
		timeout:2000,
		pause:true,
		pauseOnPagerHover:true,
		prev:'#Hareket_SliderGeri',
		next:'#Hareket_SliderIleri',
		pager:'#Hareket_SliderPager'
	});
	
	
	// YETKİLİLER SLİDER
	$('.yetkili_listele').cycle({
		fx:'scrollUp',
		//fx:'scrollHorz',
		//fx:'fade',
		easing: 'easeInOutBack',
		containerResize: false,
		slideResize: false,
		fit: 1,
		timeout:2000,
		pause:true,
		pauseOnPagerHover:true,
		prev:'#yetkili_SliderGeri',
		next:'#yetkili_SliderIleri',
		pager:'#yetkili_SliderPager'
	});
	
	
	// İLERİ GERİ BUTONLARI
	$('.Slider_Kapsayici__').hover(
		function() {
			$('#SliderGeri').stop().animate({left:460,opacity:1},500,'easeOutExpo');
			$('#SliderIleri').stop().animate({right:260,opacity:1},500,'easeOutExpo');	
		},
		function() {
			$('#SliderGeri').stop().animate({left:400,opacity:0},500,'easeOutExpo');
			$('#SliderIleri').stop().animate({right:200,opacity:0},500,'easeOutExpo');
		}
	);

	
});