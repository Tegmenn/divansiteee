/* SAYFA YÜKLENİYOR */

function Yuklendi(){	

	

	/* SAYFA YÜKLENDİKTEN SONRA ÇAĞIRMA */

	var callbackFunc = function(){

		console.log('file loaded');     

	};

	var head = document.getElementsByTagName( "head" )[0];

	var fileref=document.createElement("link");

	fileref.setAttribute("rel", "stylesheet");

	fileref.setAttribute("type", "text/css");

	fileref.setAttribute("href", "/theme/kenteleven/css/Animate.css");

	

	fileref.onload  = callbackFunc;

	head.insertBefore( fileref, head.firstChild );

		

}

window.onload = Yuklendi;





function recommentgo() {
    $("#recommesage").html('<img src="/theme/kariyer/images/Loading.gif" alt="Ajax Loader" id="comnloadasad" />').show();
    var e = $("#ad").val();
    var t = $("#email").val();
    var n = $("#yorum").val();
    var r = $("#gkod").val();
    if (e.length < 3) {
        $("#recommesage").html('<b style="color:#FF0000">Kullanıcı Adınızı Yazınız</b>').show();
        $("html, body").animate({
            scrollTop: $("div.recomhead").position().top
        }, "slow");
        $("#ad").addClass("recomalert")
    } else {
        $("#ad").removeClass("recomalert");
        var i = "1"
    }
    var s = /^[a-zA-Z0-9._-]+@([a-zA-Z0-9.-]+.)+([.])+[a-zA-Z0-9.-]{2,4}$/;
    if (s.test(t) == true) {
        $("#email").removeClass("recomalert");
        var o = "1"
    } else {
        $("#recommesage").html('<b style="color:#FF0000">Geçerli Bir Email Adresi Yazınız.</b>').show();
        $("html, body").animate({
            scrollTop: $("div.recomhead").position().top
        }, "slow");
        $("#email").addClass("recomalert")
    }
    if (n.length < 10) {
        $("#recommesage").html('<b style="color:#FF0000">Yorum Minimum 10 Karakter Olmalı.</b>').show();
        $("html, body").animate({
            scrollTop: $("div.recomhead").position().top
        }, "slow");
        $("#yorum").addClass("recomalert")
    } else {
        $("#yorum").removeClass("recomalert");
        var u = "1"
    }
    if (r.length < 3) {
        $("#recommesage").html('<b style="color:#FF0000">Güvenlik Kodunu Yazınız.</b>').show();
        $("html, body").animate({
            scrollTop: $("div.recomhead").position().top
        }, "slow");
        $("#gkod").addClass("recomalert")
    } else {
        $("#gkod").removeClass("recomalert");
        var a = "1"
    }
    if (i == 1 && o == 1 && u == 1 && a == 1) {
        var f = $("form#commentform").serialize();
        $.post("/theme/islems.php?s=comment", f, function(e) {
            if (e = "ok") {
                $("#ad").val("");
                $("#email").val("");
                $("#yorum").val("");
                $("#gkod").val("");
                chcs();
                $("#recommesage").html('<b style="color:green">Yorumunuz Onay Sonrası Yayınlanacaktır.</b>').show();
            } else {
                $("#recommesage").html(e).fadeIn().delay("5000").show();
            }
        })
    } else {
        $("#recommesage").html('<b style="color:#FF0000">Hatalı İşlem</b>').show();
    }
}

function chcs()
{
$("img#chc").attr("src","/captcha.jpg?_="+((new Date()).getTime()));
}


function imgError(image) {
    image.onerror = "";
    image.src = "/theme/kariyer/images/noimageall.png";
    return true;
}


$(document).ready(function(e) {



	

	// CHAT SAYFASI SOSYAL BUTONLAR

	$('.sosyal_btn').click(function(e) {

        $('.sosyal_butonlar').css("margin-left","424px");

        $('.sosyal_butonlar').stop().toggle().animate({ "marginLeft":"444px" },500,'easeOutExpo');

		

		if ($(".sosyal_btn").hasClass("aktif")) {

			$(this).removeClass("aktif");

		}else{

			$(this).addClass("aktif");

		}

    });

	

	

	// CHAT ÜYE RESİM

    $('.uyeler').hover(function(e) {

		$(this).find('.uye_resim_isik').stop().animate({ "marginLeft":"-20px" },500,'easeOutExpo');

	}, function(e) {

		$(this).find('.uye_resim_isik').stop().animate({ "marginLeft":"0px" },500,'easeOutExpo');

    });

	

	

	// LOGİN YAN BUTONLAR

    $('.yan_butonlar a').hover(function(e) {

		$(this).addClass('animated');

		$(this).addClass('headShake');

	}, function(e) {

		$(this).removeClass('animated');

		$(this).removeClass('headShake');

    });

	

	

	// LOGİN TAB BUTONLAR

    $('.login_buttons a').hover(function(e) {

		$(this).addClass('animated');

		$(this).addClass('fadeIn');

	}, function(e) {

		$(this).removeClass('animated');

		$(this).removeClass('fadeIn');

    });

	

	

	// LOGO EFEKT

    $('.Logo').hover(function(e) {

		$(this).find('a').addClass('float-shadow');

	}, function(e) {

		$(this).find('a').removeClass('float-shadow');

    });



	

	// MAKALE RESİM EFEKT

    $('.makale').hover(function(e) {

		$(this).find('img').addClass('animated');

		$(this).find('img').addClass('flipInX');

	}, function(e) {

		$(this).find('img').removeClass('animated');

		$(this).find('img').removeClass('flipInX');

    });

	

	

	// POPUP ÜYE RESİMLERİ EFEKT

    $('.uye_resimleri ul li').hover(function(e) {

		$(this).find('img').addClass('animated');

		$(this).find('img').addClass('flipInY');

	}, function(e) {

		$(this).find('img').removeClass('animated');

		$(this).find('img').removeClass('flipInY');

    });

	

	

	// ÜYE RESİMLER EFEKT

    $('.uye_resimler .uye_kapsayici').hover(function(e) {

		$(this).find('div').addClass('animated');

		$(this).find('div').addClass('flipInY');

	}, function(e) {

		$(this).find('div').removeClass('animated');

		$(this).find('div').removeClass('flipInY');

    });

	

	

	

	// SAYFA GALERİ EFEKT

    $('.galeri li').hover(function(e) {

		$(this).find('img').addClass('animated');

		$(this).find('img').addClass('flipInY');

	}, function(e) {

		$(this).find('img').removeClass('animated');

		$(this).find('img').removeClass('flipInY');

    });

	

	

	// YAN MENU EFEKT

    $('.yan_menu ul li').hover(function(e) {

		$(this).find('i').addClass('animated');

		$(this).find('i').addClass('flipInY');

		$(this).find('i').stop().animate({ "marginLeft":"15px" },500,'easeOutExpo');

	}, function(e) {

		$(this).find('i').removeClass('animated');

		$(this).find('i').removeClass('flipInY');

		$(this).find('i').stop().animate({ "marginLeft":"0" },500,'easeOutExpo');

    });

	

	

	// YAN MENU EFEKT

    $('.footer_menu li').hover(function(e) {

		$(this).find('i').addClass('animated');

		$(this).find('i').addClass('flipInY');

		$(this).find('i').stop().animate({ "marginLeft":"7px" },500,'easeOutExpo');

	}, function(e) {

		$(this).find('i').removeClass('animated');

		$(this).find('i').removeClass('flipInY');

		$(this).find('i').stop().animate({ "marginLeft":"0" },500,'easeOutExpo');

    });

	

	

	// ODALAR RESİM EFEKT

    $('.sohbet_odasi').hover(function(e) {

		$(this).find('img').addClass('animated');

		$(this).find('img').addClass('pulse');

	}, function(e) {

		$(this).find('img').removeClass('animated');

		$(this).find('img').removeClass('pulse');

    });

	

	

	// LOGİN BUTONLAR

    $('.login_buttons a').click(function(e) {

		$('.login_buttons a').removeClass('aktif');

        $(this).addClass('aktif');

    });

	

	

	// LOGİN FORMLAR AKTİFLİK

	$('.login_buttons a').click(function(e) {

		if ( $('.misafir_login_btn').hasClass( "aktif" ) ) {

			$('.Sifre').addClass('pasif_form');

			$('.YoneticiSifre').addClass('pasif_form');

			$('.Sifre').attr('readonly', true);

			$('.YoneticiSifre').attr('readonly', true);

		}

		if ( $('.uye_login_btn').hasClass( "aktif" ) ) {

			$('.Sifre').removeClass('pasif_form');

			$('.YoneticiSifre').addClass('pasif_form');

			$('.Sifre').attr('readonly', false);

		}

		if ( $('.yetkili_login_btn').hasClass( "aktif" ) ) {

			$('.Sifre').removeClass('pasif_form');

			$('.YoneticiSifre').removeClass('pasif_form');

			$('.Sifre').attr('readonly', false);

			$('.YoneticiSifre').attr('readonly', false);

		}

    });

	

	

 	// LOGİN BAY - BAYAN SEÇİMİ

	$('.Bay').click(function(){ 

		$(".Bayan").removeClass("aktif");

		$(this).addClass("aktif");

		$('input#cinsiyet').val("Erkek");

	});

    	

	$('.Bayan').click(function(){  

		$(".Bay").removeClass("aktif");

		$(this).addClass("aktif");

		$('input#cinsiyet').val("Bayan");

	});

	

	

	/* GO TOP */

	$('.scrollup').click(function(){  

		window.scrollTo(500, 0);

	});

	

	

});