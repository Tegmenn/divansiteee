/* SAYFA YÜKLENİYOR */
function Yuklendi(){	
	
	/* SAYFA YÜKLENDİKTEN SONRA ÇAĞIRMA */
	var callbackFunc = function(){
		console.log('file loaded');     
	};
	var head = document.getElementsByTagName( "head" )[0];
	var fileref=document.createElement("link");
	fileref.setAttribute("rel", "stylesheet");
	fileref.setAttribute("type", "text/css");
	fileref.setAttribute("href", "Css/Animate.css");
	
	fileref.onload  = callbackFunc;
	head.insertBefore( fileref, head.firstChild );
		
}
window.onload = Yuklendi;

function imgError(image) {
    image.onerror = "";
    image.src = "/theme/perfect/img/noimageall.png";
    return true;
}



$(document).ready(function(e) {

	
	// CHAT SAYFASI SOL BUTONLAR
    $('.chat_butonlar a').hover(function(e) {
		$(this).stop().animate({ "marginTop":"-3px" },500,'easeOutExpo');
	}, function(e) {
		$(this).stop().animate({ "marginTop":"0" },500,'easeOutExpo');
    });
	
	
	// LOGİN BAYRAKLAR
    $('.icon_menu a').hover(function(e) {
		$(this).stop().animate({ "marginTop":"4px" },500,'easeOutExpo');
	}, function(e) {
		$(this).stop().animate({ "marginTop":"0" },500,'easeOutExpo');
    });
	
		// LOGİN BAYRAKLAR
    $('.icon1_menu a').hover(function(e) {
		$(this).stop().animate({ "marginTop":"4px" },500,'easeOutExpo');
	}, function(e) {
		$(this).stop().animate({ "marginTop":"0" },500,'easeOutExpo');
    });
	
	// ÜYE RESİMLERİ HOVER
    $('.uye_resimleri_grup1').hover(function(e) {
		$(this).stop().animate({ "right":"0px" },500,'easeOutExpo');
	}, function(e) {
		$(this).stop().animate({ "right":"-20px" },500,'easeOutExpo');
    });
	
	
	// ÜYE RESİMLERİ 2 HOVER
    $('.uye_resimleri_grup2').hover(function(e) {
		$(this).stop().animate({ "right":"-50px" },500,'easeOutExpo');
	}, function(e) {
		$(this).stop().animate({ "right":"-70px" },500,'easeOutExpo');
    });
	
	
	// CHAT ÜYE RESİM
    $('.uyeler').hover(function(e) {
		$(this).find('.uye_resim_isik').stop().animate({ "marginLeft":"-20px" },500,'easeOutExpo');
	}, function(e) {
		$(this).find('.uye_resim_isik').stop().animate({ "marginLeft":"0px" },500,'easeOutExpo');
    });
	
	
	// LOGİN YAN BUTONLAR
    $('.yan_butonlar a').hover(function(e) {
		$(this).addClass('animated');
		$(this).addClass('headShake');
	}, function(e) {
		$(this).removeClass('animated');
		$(this).removeClass('headShake');
    });
	
	
	// LOGİN TAB BUTONLAR
    $('.login_buttons a').hover(function(e) {
		$(this).addClass('animated');
		$(this).addClass('fadeIn');
	}, function(e) {
		$(this).removeClass('animated');
		$(this).removeClass('fadeIn');
    });
	
	
	// LOGO EFEKT
    $('.Logo').hover(function(e) {
		$(this).find('a').addClass('float-shadow');
	}, function(e) {
		$(this).find('a').removeClass('float-shadow');
    });

	
	// MAKALE RESİM EFEKT
    $('.makale').hover(function(e) {
		$(this).find('img').addClass('animated');
		$(this).find('img').addClass('flipInY');
	}, function(e) {
		$(this).find('img').removeClass('animated');
		$(this).find('img').removeClass('flipInY');
    });
	
	
	// POPUP ÜYE RESİMLERİ EFEKT
    $('.uye_resimleri ul li').hover(function(e) {
		$(this).find('img').addClass('animated');
		$(this).find('img').addClass('flipInX');
	}, function(e) {
		$(this).find('img').removeClass('animated');
		$(this).find('img').removeClass('flipInX');
    });
	
	
	
	// SAYFA GALERİ EFEKT
    $('.galeri li').hover(function(e) {
		$(this).find('img').addClass('animated');
		$(this).find('img').addClass('flipInY');
	}, function(e) {
		$(this).find('img').removeClass('animated');
		$(this).find('img').removeClass('flipInY');
    });
	
	
	// YAN MENU EFEKT
    $('.yan_menu ul li').hover(function(e) {
		$(this).find('i').addClass('animated');
		$(this).find('i').addClass('flipInY');
		$(this).find('i').stop().animate({ "marginLeft":"15px" },500,'easeOutExpo');
	}, function(e) {
		$(this).find('i').removeClass('animated');
		$(this).find('i').removeClass('flipInY');
		$(this).find('i').stop().animate({ "marginLeft":"0" },500,'easeOutExpo');
    });
	
	
	// YAN MENU EFEKT
    $('.footer_menu li').hover(function(e) {
		$(this).find('i').addClass('animated');
		$(this).find('i').addClass('flipInY');
		$(this).find('i').stop().animate({ "marginLeft":"7px" },500,'easeOutExpo');
	}, function(e) {
		$(this).find('i').removeClass('animated');
		$(this).find('i').removeClass('flipInY');
		$(this).find('i').stop().animate({ "marginLeft":"0" },500,'easeOutExpo');
    });
	
	
	// ODALAR RESİM EFEKT
    $('.sohbet_odasi').hover(function(e) {
		$(this).find('img').addClass('animated');
		$(this).find('img').addClass('pulse');
	}, function(e) {
		$(this).find('img').removeClass('animated');
		$(this).find('img').removeClass('pulse');
    });
	
	
	// LOGİN BUTONLAR
    $('.login_buttons a').click(function(e) {
		$('.login_buttons a').removeClass('aktif');
        $(this).addClass('aktif');
    });
	
	
	// LOGİN FORMLAR AKTİFLİK
	$('.login_buttons a').click(function(e) {
		if ( $('.misafir_login_btn').hasClass( "aktif" ) ) {
			$('.Sifre').addClass('pasif_form');
			$('.YoneticiSifre').addClass('pasif_form');
			$('.Sifre').attr('readonly', true);
			$('.YoneticiSifre').attr('readonly', true);
		}
		if ( $('.uye_login_btn').hasClass( "aktif" ) ) {
			$('.Sifre').removeClass('pasif_form');
			$('.YoneticiSifre').addClass('pasif_form');
			$('.Sifre').attr('readonly', false);
		}
		if ( $('.yetkili_login_btn').hasClass( "aktif" ) ) {
			$('.Sifre').removeClass('pasif_form');
			$('.YoneticiSifre').removeClass('pasif_form');
			$('.Sifre').attr('readonly', false);
			$('.YoneticiSifre').attr('readonly', false);
		}
    });
	
	
 	// LOGİN BAY - BAYAN SEÇİMİ
	$('.Bay').click(function(){ 
		$(".Bayan").removeClass("aktif");
		$(this).addClass("aktif");
		$('input#cinsiyet').val("Erkek");
	});
    	
	$('.Bayan').click(function(){  
		$(".Bay").removeClass("aktif");
		$(this).addClass("aktif");
		$('input#cinsiyet').val("Bayan");
	});
	
	
	/* GO TOP */
	$('.scrollup').click(function(){  
		window.scrollTo(500, 0);
	});
	
	
});


	// DUVAR YAZILARI
	$('.duvar_yazilari_listele').cycle({
		fx:'scrollUp',
		//fx:'scrollHorz',
		//fx:'fade',
		easing: 'easeInOutBack',
		containerResize: false,
		slideResize: false,
		fit: 1,
		timeout:10000,
		pause:true,
		pauseOnPagerHover:true,
		prev:'#Duvar_SliderGeri',
		next:'#Duvar_SliderIleri',
		pager:'#Duvar_SliderPager'
	});


/* BG SABİTLEME */
$(window).scroll(function () { 
	var sT = $(window).scrollTop();
	
	if (sT > 2000) { 
		if ($('body').addClass('Bg_Sabit').is(':animated')) {
			return false;
		} else {
			$('body').addClass('Bg_Sabit').animate( { 
				top : 0,
				//opacity : 1 
			}, 500);
		}
	} else { 
		$('body').removeClass('Bg_Sabit').stop().attr( { style : '' } );
	}
} );